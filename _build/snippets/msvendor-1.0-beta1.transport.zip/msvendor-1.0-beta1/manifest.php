<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6d8669a5ef1776e989137d69af3ebc8c',
      'native_key' => 'msvendor',
      'filename' => 'modNamespace/8598b4f5910b130f4aa649b80af9cf1e.vehicle',
      'namespace' => 'msvendor',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8d818b8161f84538ca0c4ca44bf8db7c',
      'native_key' => 1,
      'filename' => 'modCategory/a7bb84125fc3cb7dbf337ae8c084b37f.vehicle',
      'namespace' => 'msvendor',
    ),
  ),
);